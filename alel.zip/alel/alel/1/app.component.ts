import { Component } from '@angular/core';

@Component({
  template: `
    <h1>Products</h1>
    <app-product></app-product>
  `,
})
export class AppComponent {}