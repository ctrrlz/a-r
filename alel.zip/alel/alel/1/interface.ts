export interface Product {
    name: string;
    calories?: number;
    protein?: number;
    fats?: number;
    uglevod?: number;
    imagePath?: string;
  }
  