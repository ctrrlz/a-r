//вариант 0(задание практика(2))
import { Component } from '@angular/core'

@Component({
    selector: 'app-root',
    template: `<h1>Hello, Angular</h1>`
})
export class HelloComponent{}
    