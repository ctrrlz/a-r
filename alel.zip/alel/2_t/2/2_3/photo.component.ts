//вариант 0(задание практика(4))
import { Component } from '@angular/core'

@Component({
    selector: 'app-root',
    template: `<img src=image/auto.jpg></img>
    <img src=image/logo.png></img>
    <img src=image/port.jpg></img>`
})
export class PhotoComponent{}